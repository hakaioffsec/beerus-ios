import SwiftUI

@main
struct JailbreakDetectorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
