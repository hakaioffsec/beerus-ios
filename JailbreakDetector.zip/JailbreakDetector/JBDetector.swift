import Foundation
import UIKit
import Darwin.POSIX
import MachO
import ObjectiveC.runtime

// ponytail: EXC_MASK_ALL unavailable in Swift, define manually
private let EXC_MASK_ALL: exception_mask_t = 0x1FFE // covers EXC_BAD_ACCESS through EXC_CORPSE_NOTIFY

struct CheckResult: Identifiable {
    let id = UUID()
    let name: String
    let detected: Bool
    let details: String
}

enum JBDetector {

    private static let logPath = "/var/mobile/.jbdetector_log"

    private static func log(_ msg: String) {
        let line = "[\(Date())] \(msg)\n"
        if let data = line.data(using: .utf8) {
            if FileManager.default.fileExists(atPath: logPath) {
                if let h = FileHandle(forWritingAtPath: logPath) {
                    h.seekToEndOfFile()
                    h.write(data)
                    h.closeFile()
                }
            } else {
                FileManager.default.createFile(atPath: logPath, contents: data)
            }
        }
    }

    static func runAllChecks() -> [CheckResult] {
        var results: [CheckResult] = []
        try? FileManager.default.removeItem(atPath: logPath)
        log("=== JBDetector START ===")

        // 1. File existence (80+ paths)
        let paths = [
            "/var/jb", "/private/var/jb",
            "/Applications/Cydia.app", "/Applications/Sileo.app", "/Applications/Zebra.app",
            "/Applications/Filza.app", "/Applications/FlyJB.app",
            "/usr/sbin/frida-server", "/var/jb/usr/sbin/frida-server",
            "/usr/bin/cycript", "/usr/sbin/sshd",
            "/Library/MobileSubstrate", "/var/jb/Library/MobileSubstrate",
            "/Library/Frameworks/CydiaSubstrate.framework",
            "/usr/lib/libjailbreak.dylib",
            "/etc/apt", "/var/lib/apt", "/var/lib/cydia",
            "/private/var/stash", "/var/stash",
            "/.installed_unc0ver", "/.installed_dopamine", "/.installed_palera1n",
            "/.bootstrapped_electra",
            "/cores/binpack",
            "/var/mobile/Library/SBSettings",
            "/jb", "/electra", "/chimera",
            // Additional paths
            "/var/mobile/Library/Preferences/ABPattern",
            "/usr/lib/ABDYLD.dylib", "/usr/lib/ABSubLoader.dylib",
            "/Library/BawAppie/ABypass",
            "/var/mobile/Library/Preferences/me.jjolano.shadow.plist",
            "/Library/PreferenceBundles/ShadowPreferences.bundle",
            "/Library/MobileSubstrate/DynamicLibraries/PreferenceLoader.plist",
            "/Library/MobileSubstrate/DynamicLibraries/SSLKillSwitch2.plist",
            "/etc/apt/sources.list.d/electra.list",
            "/etc/apt/sources.list.d/sileo.sources",
            "/jb/lzma", "/jb/offsets.plist", "/jb/jailbreakd.plist",
            "/jb/amfid_payload.dylib", "/jb/libjailbreak.dylib",
            "/usr/share/jailbreak/injectme.plist",
            "/var/lib/dpkg/info/mobilesubstrate.md5sums",
            "/var/binpack/Applications/loader.app",
            "/usr/lib/libhooker.dylib", "/usr/lib/libsubstitute.dylib",
            "/usr/lib/substrate", "/usr/lib/TweakInject",
            "/Library/PreferenceBundles/Cephei.bundle",
            "/var/lib/undecimus/apt", "/usr/include", "/usr/share"
        ]
        var found: [String] = []
        for path in paths {
            if FileManager.default.fileExists(atPath: path) {
                found.append(path)
            }
        }
        results.append(CheckResult(
            name: "File Existence",
            detected: !found.isEmpty,
            details: found.isEmpty ? "Clean" : "\(found.count) JB paths found"
        ))

        // 2. URL schemes
        let schemes = ["cydia://", "sileo://", "zebra://", "filza://",
                      "activator://", "undecimus://", "odyssey://",
                      "electra://", "chimera://", "taurine://", "dopamine://"]
        var openable: [String] = []
        for scheme in schemes {
            if let url = URL(string: scheme), UIApplication.shared.canOpenURL(url) {
                openable.append(scheme)
            }
        }
        results.append(CheckResult(
            name: "URL Schemes",
            detected: !openable.isEmpty,
            details: openable.isEmpty ? "Clean" : "\(openable.count) JB schemes"
        ))

        // 3. Fork test (safe implementation)
        var forkWorks = false
        typealias ForkFn = @convention(c) () -> Int32
        if let sym = dlsym(UnsafeMutableRawPointer(bitPattern: -2), "fork") {
            let fn = unsafeBitCast(sym, to: ForkFn.self)
            let pid = fn()
            if pid == 0 {
                _exit(0)
            } else if pid > 0 {
                var status: Int32 = 0
                waitpid(pid, &status, 0)
                forkWorks = true
            }
        }
        results.append(CheckResult(
            name: "Fork Test",
            detected: forkWorks,
            details: forkWorks ? "fork() works - sandbox bypassed" : "fork() blocked"
        ))

        // 4. Sandbox write
        let testPath = "/private/jailbreak_test_\(arc4random())"
        let canWrite = FileManager.default.createFile(atPath: testPath, contents: Data("x".utf8))
        if canWrite { try? FileManager.default.removeItem(atPath: testPath) }
        results.append(CheckResult(
            name: "Sandbox Write",
            detected: canWrite,
            details: canWrite ? "Can write /private" : "Sandbox OK"
        ))

        // 5. Dyld images (expanded keywords)
        var suspicious: [String] = []
        let keywords = [
            "substrate", "substitute", "frida", "cycript",
            "libhooker", "ellekit", "tweakinject", "pspawn", "jailbreak",
            // Additional keywords
            "systemhook", "roothideinit", "sslkillswitch", "shadow",
            "cephei", "appsyncunified", "preferenceloader", "rocketbootstrap",
            "weeloader", "cynject", "hidejb"
        ]
        let count = _dyld_image_count()
        for i in 0..<count {
            if let name = _dyld_get_image_name(i) {
                let path = String(cString: name).lowercased()
                for kw in keywords where path.contains(kw) {
                    suspicious.append(String(cString: name))
                    break
                }
            }
        }
        results.append(CheckResult(
            name: "Dyld Images",
            detected: !suspicious.isEmpty,
            details: suspicious.isEmpty ? "Clean" : "\(suspicious.count) JB dylibs"
        ))

        // 6. Environment
        var envFound: [String] = []
        let envVars = ["DYLD_INSERT_LIBRARIES", "DYLD_LIBRARY_PATH", "_MSSafeMode"]
        for v in envVars {
            if getenv(v) != nil { envFound.append(v) }
        }
        results.append(CheckResult(
            name: "Environment",
            detected: !envFound.isEmpty,
            details: envFound.isEmpty ? "Clean" : envFound.joined(separator: ", ")
        ))

        // 7. Symlink /var/jb
        var isSymlink = false
        var st = stat()
        if lstat("/var/jb", &st) == 0 {
            isSymlink = (st.st_mode & S_IFMT) == S_IFLNK
        }
        results.append(CheckResult(
            name: "Symlink /var/jb",
            detected: isSymlink,
            details: isSymlink ? "Symlink exists" : "Not found"
        ))

        // 8. System files readable
        var sysReadable = false
        if let _ = try? String(contentsOfFile: "/etc/passwd", encoding: .utf8) {
            sysReadable = true
        }
        results.append(CheckResult(
            name: "System Files",
            detected: sysReadable,
            details: sysReadable ? "/etc/passwd readable" : "Blocked"
        ))

        // 9. SSH port check (expanded ports: 22, 27043, 4444, 44)
        let portsToCheck: [(UInt16, String)] = [(22, "SSH"), (27043, "Frida-Alt"), (4444, "Reverse Shell"), (44, "Checkra1n")]
        var openPorts: [String] = []
        for (port, label) in portsToCheck {
            let sock = socket(AF_INET, SOCK_STREAM, 0)
            if sock >= 0 {
                var addr = sockaddr_in()
                addr.sin_family = sa_family_t(AF_INET)
                addr.sin_port = CFSwapInt16HostToBig(port)
                addr.sin_addr.s_addr = inet_addr("127.0.0.1")
                var tv = timeval(tv_sec: 1, tv_usec: 0)
                setsockopt(sock, SOL_SOCKET, SO_SNDTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
                let connected = withUnsafePointer(to: &addr) { ptr in
                    ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                        connect(sock, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) == 0
                    }
                }
                close(sock)
                if connected { openPorts.append("\(port):\(label)") }
            }
        }
        results.append(CheckResult(
            name: "JB Ports",
            detected: !openPorts.isEmpty,
            details: openPorts.isEmpty ? "All closed" : openPorts.joined(separator: ", ")
        ))

        // 10. Frida port check
        var fridaOpen = false
        let fsock = socket(AF_INET, SOCK_STREAM, 0)
        if fsock >= 0 {
            var addr = sockaddr_in()
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = CFSwapInt16HostToBig(27042)
            addr.sin_addr.s_addr = inet_addr("127.0.0.1")
            var tv = timeval(tv_sec: 1, tv_usec: 0)
            setsockopt(fsock, SOL_SOCKET, SO_SNDTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
            let connected = withUnsafePointer(to: &addr) { ptr in
                ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    connect(fsock, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) == 0
                }
            }
            close(fsock)
            fridaOpen = connected
        }
        results.append(CheckResult(
            name: "Frida Port",
            detected: fridaOpen,
            details: fridaOpen ? "27042 open" : "Closed"
        ))

        // 11. Injected dylibs (compare expected vs loaded)
        let loadedCount = Int(_dyld_image_count())
        let injected = loadedCount > 200 // normal app has ~180-200
        results.append(CheckResult(
            name: "Injected Dylibs",
            detected: injected,
            details: "\(loadedCount) images loaded"
        ))

        // ============ NEW CHECKS ============

        // 12. sysctl P_TRACED Debugger Check
        var isTraced = false
        var info = kinfo_proc()
        var mib: [Int32] = [CTL_KERN, KERN_PROC, KERN_PROC_PID, getpid()]
        var size = MemoryLayout<kinfo_proc>.stride
        if sysctl(&mib, 4, &info, &size, nil, 0) == 0 {
            isTraced = (info.kp_proc.p_flag & P_TRACED) != 0
        }
        results.append(CheckResult(
            name: "P_TRACED Debug",
            detected: isTraced,
            details: isTraced ? "Debugger attached" : "Not traced"
        ))

        // 13. Parent PID Check
        let ppid = getppid()
        let abnormalParent = ppid != 1
        results.append(CheckResult(
            name: "Parent PID",
            detected: abnormalParent,
            details: "ppid=\(ppid)" + (abnormalParent ? " (not launchd)" : "")
        ))

        // 14. stat() Syscall Direct
        var statSt = Darwin.stat()
        let existsViaStat = stat("/var/jb", &statSt) == 0
        results.append(CheckResult(
            name: "stat() /var/jb",
            detected: existsViaStat,
            details: existsViaStat ? "Exists via syscall" : "Not found"
        ))

        // 15. statfs() Read-Only Root Check
        var fs = statfs()
        var rootWritable = false
        if statfs("/", &fs) == 0 {
            rootWritable = (fs.f_flags & UInt32(MNT_RDONLY)) == 0
        }
        results.append(CheckResult(
            name: "Root Writable",
            detected: rootWritable,
            details: rootWritable ? "/ is writable" : "/ is read-only"
        ))

        // 16. Mach Exception Ports Check
        var hasExceptionPorts = false
        var excCount: mach_msg_type_number_t = 0
        var masks = [exception_mask_t](repeating: 0, count: Int(EXC_TYPES_COUNT))
        var ports = [mach_port_t](repeating: 0, count: Int(EXC_TYPES_COUNT))
        var behaviors = [exception_behavior_t](repeating: 0, count: Int(EXC_TYPES_COUNT))
        var flavors = [thread_state_flavor_t](repeating: 0, count: Int(EXC_TYPES_COUNT))
        let kr = task_get_exception_ports(
            mach_task_self_,
            exception_mask_t(EXC_MASK_ALL),
            &masks,
            &excCount,
            &ports,
            &behaviors,
            &flavors
        )
        if kr == KERN_SUCCESS {
            for i in 0..<Int(excCount) {
                if ports[i] != 0 {
                    hasExceptionPorts = true
                    break
                }
            }
        }
        results.append(CheckResult(
            name: "Exception Ports",
            detected: hasExceptionPorts,
            details: hasExceptionPorts ? "Ports registered" : "Clean"
        ))

        // 17. Frida Thread Names
        let suspiciousThreadNames = ["gum-js-loop", "gmain", "gdbus", "pool-frida", "frida"]
        var hasFridaThreads = false
        var foundThreadName = ""
        var thread_list: thread_act_array_t?
        var thread_count: mach_msg_type_number_t = 0
        if task_threads(mach_task_self_, &thread_list, &thread_count) == KERN_SUCCESS, let threads = thread_list {
            outer: for i in 0..<Int(thread_count) {
                var name = [CChar](repeating: 0, count: 64)
                guard let pthread = pthread_from_mach_thread_np(threads[i]) else { continue }
                pthread_getname_np(pthread, &name, 64)
                let threadName = String(cString: name).lowercased()
                for sus in suspiciousThreadNames where threadName.contains(sus) {
                    hasFridaThreads = true
                    foundThreadName = threadName
                    break outer
                }
            }
            vm_deallocate(
                mach_task_self_,
                vm_address_t(bitPattern: threads),
                vm_size_t(thread_count) * vm_size_t(MemoryLayout<thread_t>.stride)
            )
        }
        results.append(CheckResult(
            name: "Frida Threads",
            detected: hasFridaThreads,
            details: hasFridaThreads ? "Found: \(foundThreadName)" : "Clean"
        ))

        // 18. ObjC Bypass Classes Detection
        let bypassClasses = ["ShadowRuleset", "ABPattern", "FlyJBX", "HideJB", "Liberty"]
        var hasBypassTweaks = false
        var foundClass = ""
        for cls in bypassClasses {
            if objc_getClass(cls) != nil {
                hasBypassTweaks = true
                foundClass = cls
                break
            }
        }
        results.append(CheckResult(
            name: "Bypass Tweaks",
            detected: hasBypassTweaks,
            details: hasBypassTweaks ? "Found: \(foundClass)" : "Clean"
        ))

        // 19. Simulator Detection
        var isSimulator = false
        #if targetEnvironment(simulator)
        isSimulator = true
        #else
        if ProcessInfo.processInfo.environment["SIMULATOR_DEVICE_NAME"] != nil {
            isSimulator = true
        }
        #endif
        results.append(CheckResult(
            name: "Simulator",
            detected: isSimulator,
            details: isSimulator ? "Running in simulator" : "Real device"
        ))

        // 20. Function Prologue Check (stat hook detection)
        var isStatHooked = false
        if let statPtr = dlsym(UnsafeMutableRawPointer(bitPattern: -2), "stat") {
            let bytes = statPtr.assumingMemoryBound(to: UInt32.self)
            let first = bytes.pointee
            // ARM64 branch instructions: B (0x14xxxxxx), BL (0x94xxxxxx)
            if (first & 0xFC000000) == 0x14000000 || (first & 0xFC000000) == 0x94000000 {
                isStatHooked = true
            }
        }
        results.append(CheckResult(
            name: "stat() Hooked",
            detected: isStatHooked,
            details: isStatHooked ? "Branch at prologue" : "Unmodified"
        ))

        // 21. Frida/Gadget Strings in Dyld Images
        var hasFridaStrings = false
        var fridaImagePath = ""
        for i in 0..<_dyld_image_count() {
            if let name = _dyld_get_image_name(i) {
                let path = String(cString: name).lowercased()
                if path.contains("frida") || path.contains("gadget") {
                    hasFridaStrings = true
                    fridaImagePath = String(cString: name)
                    break
                }
            }
        }
        results.append(CheckResult(
            name: "Frida Images",
            detected: hasFridaStrings,
            details: hasFridaStrings ? fridaImagePath : "Clean"
        ))

        // 22. D-Bus Protocol Detection (Frida uses D-Bus on 27042)
        var dbusDetected = false
        let dbSock = socket(AF_INET, SOCK_STREAM, 0)
        if dbSock >= 0 {
            var addr = sockaddr_in()
            addr.sin_family = sa_family_t(AF_INET)
            addr.sin_port = CFSwapInt16HostToBig(27042)
            addr.sin_addr.s_addr = inet_addr("127.0.0.1")
            var tv = timeval(tv_sec: 1, tv_usec: 0)
            setsockopt(dbSock, SOL_SOCKET, SO_SNDTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
            setsockopt(dbSock, SOL_SOCKET, SO_RCVTIMEO, &tv, socklen_t(MemoryLayout<timeval>.size))
            let connected = withUnsafePointer(to: &addr) { ptr in
                ptr.withMemoryRebound(to: sockaddr.self, capacity: 1) {
                    connect(dbSock, $0, socklen_t(MemoryLayout<sockaddr_in>.size)) == 0
                }
            }
            if connected {
                // Send D-Bus AUTH command
                let auth = "\0AUTH\r\n"
                _ = auth.withCString { send(dbSock, $0, strlen($0), 0) }
                var buf = [CChar](repeating: 0, count: 128)
                let n = recv(dbSock, &buf, 127, 0)
                if n > 0 {
                    let resp = String(cString: buf).uppercased()
                    // Frida responds to D-Bus protocol
                    if resp.contains("REJECT") || resp.contains("OK") || resp.contains("ERROR") {
                        dbusDetected = true
                    }
                }
            }
            close(dbSock)
        }
        results.append(CheckResult(
            name: "D-Bus Protocol",
            detected: dbusDetected,
            details: dbusDetected ? "D-Bus on 27042" : "Not detected"
        ))

        // 23. ptrace PT_DENY_ATTACH (call once to harden)
        // ponytail: detection value minimal, but call blocks debuggers
        var ptraceBlocked = false
        typealias PtraceFn = @convention(c) (Int32, Int32, Int32, Int32) -> Int32
        if let sym = dlsym(UnsafeMutableRawPointer(bitPattern: -2), "ptrace") {
            let fn = unsafeBitCast(sym, to: PtraceFn.self)
            let PT_DENY_ATTACH: Int32 = 31
            let result = fn(PT_DENY_ATTACH, 0, 0, 0)
            // If already denied or fails, result is -1
            ptraceBlocked = result == -1
        }
        results.append(CheckResult(
            name: "PT_DENY_ATTACH",
            detected: ptraceBlocked,
            details: ptraceBlocked ? "Already denied/hooked" : "Applied"
        ))

        // 24. access() Syscall Direct
        let accessExists = access("/var/jb", F_OK) == 0
        results.append(CheckResult(
            name: "access() /var/jb",
            detected: accessExists,
            details: accessExists ? "Exists via access()" : "Not found"
        ))

        // 25. /etc/fstab Modified Check
        var fstabModified = false
        if let fstab = try? String(contentsOfFile: "/etc/fstab", encoding: .utf8) {
            // Stock fstab is minimal; JB often adds entries
            let lines = fstab.components(separatedBy: "\n").filter { !$0.isEmpty && !$0.hasPrefix("#") }
            fstabModified = lines.count > 2
        }
        results.append(CheckResult(
            name: "/etc/fstab",
            detected: fstabModified,
            details: fstabModified ? "Modified" : "Stock or unreadable"
        ))

        // 26. dyld_get_image_header Slide Check (unusual ASLR)
        var unusualSlide = false
        if _dyld_image_count() > 0 {
            let slide = _dyld_get_image_vmaddr_slide(0)
            // Normal slides are positive; weird values may indicate tampering
            unusualSlide = slide == 0 || slide < 0
        }
        results.append(CheckResult(
            name: "ASLR Slide",
            detected: unusualSlide,
            details: unusualSlide ? "Unusual slide" : "Normal"
        ))

        // 27. getfsstat() Multiple Mounts Check
        var suspiciousMounts = false
        var mountCount = getfsstat(nil, 0, MNT_NOWAIT)
        if mountCount > 0 {
            var stats = [Darwin.statfs](repeating: Darwin.statfs(), count: Int(mountCount))
            mountCount = getfsstat(&stats, Int32(MemoryLayout<statfs>.stride * Int(mountCount)), MNT_NOWAIT)
            for s in stats {
                let mountPoint = withUnsafePointer(to: s.f_mntonname) { ptr -> String in
                    ptr.withMemoryRebound(to: CChar.self, capacity: Int(MAXPATHLEN)) {
                        String(cString: $0)
                    }
                }
                // Look for jailbreak-related mount points
                if mountPoint.contains("/var/jb") || mountPoint.contains("/var/binpack") {
                    suspiciousMounts = true
                    break
                }
            }
        }
        results.append(CheckResult(
            name: "Suspicious Mounts",
            detected: suspiciousMounts,
            details: suspiciousMounts ? "JB mount found" : "Clean"
        ))

        // 28. /var/tmp Writable Check
        let varTmpTest = "/var/tmp/jb_test_\(arc4random())"
        let varTmpWritable = FileManager.default.createFile(atPath: varTmpTest, contents: Data("x".utf8))
        if varTmpWritable { try? FileManager.default.removeItem(atPath: varTmpTest) }
        results.append(CheckResult(
            name: "/var/tmp Write",
            detected: varTmpWritable,
            details: varTmpWritable ? "Writable" : "Blocked"
        ))

        // 29. Bundle Path Check (running from unusual location)
        let bundlePath = Bundle.main.bundlePath
        let unusualPath = !bundlePath.hasPrefix("/var/containers/Bundle/Application/") &&
                          !bundlePath.hasPrefix("/private/var/containers/Bundle/Application/")
        results.append(CheckResult(
            name: "Bundle Path",
            detected: unusualPath,
            details: unusualPath ? "Unusual: \(bundlePath)" : "Normal"
        ))

        // 30. sysctl HW Model Check (detect some emulators)
        var hwModel = ""
        var modelSize: size_t = 0
        sysctlbyname("hw.model", nil, &modelSize, nil, 0)
        if modelSize > 0 {
            var model = [CChar](repeating: 0, count: modelSize)
            sysctlbyname("hw.model", &model, &modelSize, nil, 0)
            hwModel = String(cString: model)
        }
        let suspiciousModel = hwModel.isEmpty || hwModel.lowercased().contains("vmware") ||
                              hwModel.lowercased().contains("virtual")
        results.append(CheckResult(
            name: "HW Model",
            detected: suspiciousModel,
            details: hwModel.isEmpty ? "Unknown" : hwModel
        ))

        // Log all results
        log("=== RESULTS ===")
        for r in results {
            log("\(r.name): detected=\(r.detected)")
        }
        let detected = results.filter { $0.detected }.count
        log("=== TOTAL: \(detected)/\(results.count) detected ===")

        return results
    }

    static var isJailbroken: Bool {
        runAllChecks().contains { $0.detected }
    }
}
